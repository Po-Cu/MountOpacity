#!/usr/bin/env bash
set -euo pipefail

echo "正在安装 Java 25..."

OS="$(uname -s)"
ARCH="$(uname -m)"

case "$OS" in
  Darwin)
    PLATFORM="mac"
    PROFILE_FILE="$HOME/.zshrc"
    ;;
  Linux)
    PLATFORM="linux"
    PROFILE_FILE="$HOME/.bashrc"
    ;;
  *)
    echo "不支持的系统：$OS"
    exit 1
    ;;
esac

case "$ARCH" in
  x86_64 | amd64)
    API_ARCH="x64"
    ;;
  arm64 | aarch64)
    API_ARCH="aarch64"
    ;;
  *)
    echo "不支持的 CPU 架构：$ARCH"
    exit 1
    ;;
esac

INSTALL_ROOT="$HOME/.jdks"
JDK_HOME="$INSTALL_ROOT/jdk-25"
WORK_DIR="${TMPDIR:-/tmp}/java25-install"
ARCHIVE="$WORK_DIR/jdk-25.tar.gz"
API_URL="https://api.adoptium.net/v3/binary/latest/25/ga/${PLATFORM}/${API_ARCH}/jdk/hotspot/normal/eclipse?project=jdk"

mkdir -p "$INSTALL_ROOT" "$WORK_DIR"

if [ -x "$JDK_HOME/bin/java" ]; then
  echo "检测到 Java 25 已安装在：$JDK_HOME"
else
  echo "正在下载 JDK 25，可能需要几分钟..."
  curl -L "$API_URL" -o "$ARCHIVE"

  EXTRACT_DIR="$WORK_DIR/extract"
  rm -rf "$EXTRACT_DIR"
  mkdir -p "$EXTRACT_DIR"

  echo "正在解压 JDK 25..."
  tar -xzf "$ARCHIVE" -C "$EXTRACT_DIR"

  JAVA_BIN="$(find "$EXTRACT_DIR" -path "*/bin/java" -type f | head -n 1)"
  if [ -z "$JAVA_BIN" ]; then
    echo "没有在压缩包中找到 bin/java，请检查下载是否完整。"
    exit 1
  fi

  REAL_JDK_HOME="$(cd "$(dirname "$JAVA_BIN")/.." && pwd)"

  rm -rf "$JDK_HOME"
  mv "$REAL_JDK_HOME" "$JDK_HOME"
fi

if [ "$PLATFORM" = "mac" ] && [ -d "$JDK_HOME/Contents/Home" ]; then
  EFFECTIVE_JAVA_HOME="$JDK_HOME/Contents/Home"
else
  EFFECTIVE_JAVA_HOME="$JDK_HOME"
fi

touch "$PROFILE_FILE"

if ! grep -q "JAVA_HOME=.*jdk-25" "$PROFILE_FILE"; then
  {
    echo ""
    echo "# Java 25"
    echo "export JAVA_HOME=\"$EFFECTIVE_JAVA_HOME\""
    echo "export PATH=\"\$JAVA_HOME/bin:\$PATH\""
  } >> "$PROFILE_FILE"
fi

export JAVA_HOME="$EFFECTIVE_JAVA_HOME"
export PATH="$JAVA_HOME/bin:$PATH"

echo ""
echo "Java 25 安装并配置完成。"
echo "安装位置：$EFFECTIVE_JAVA_HOME"
echo ""
echo "当前窗口验证结果："
java -version
javac -version
echo ""
echo "请关闭并重新打开终端，或运行："
echo "  source \"$PROFILE_FILE\""
echo ""
echo "然后进入 Mod 项目目录运行："
echo "  ./gradlew build"
