$ErrorActionPreference = "Stop"

Write-Host "正在安装 Java 25..." -ForegroundColor Cyan

$installRoot = Join-Path $env:USERPROFILE ".jdks"
$jdkHome = Join-Path $installRoot "jdk-25"
$downloadDir = Join-Path $env:TEMP "java25-install"
$zipPath = Join-Path $downloadDir "jdk-25.zip"
$apiUrl = "https://api.adoptium.net/v3/binary/latest/25/ga/windows/x64/jdk/hotspot/normal/eclipse?project=jdk"

New-Item -ItemType Directory -Force -Path $installRoot | Out-Null
New-Item -ItemType Directory -Force -Path $downloadDir | Out-Null

if (Test-Path (Join-Path $jdkHome "bin\java.exe")) {
    Write-Host "检测到 Java 25 已安装在：$jdkHome" -ForegroundColor Green
} else {
    Write-Host "正在下载 JDK 25，可能需要几分钟..." -ForegroundColor Cyan
    Invoke-WebRequest -Uri $apiUrl -OutFile $zipPath

    $extractPath = Join-Path $downloadDir "extract"
    if (Test-Path $extractPath) {
        Remove-Item -Recurse -Force $extractPath
    }
    New-Item -ItemType Directory -Force -Path $extractPath | Out-Null

    Write-Host "正在解压 JDK 25..." -ForegroundColor Cyan
    Expand-Archive -Path $zipPath -DestinationPath $extractPath -Force

    $javaExe = Get-ChildItem -Path $extractPath -Filter "java.exe" -Recurse |
        Where-Object { $_.FullName -like "*\bin\java.exe" } |
        Select-Object -First 1

    if (-not $javaExe) {
        throw "没有在压缩包中找到 bin\java.exe，请检查下载是否完整。"
    }

    $realJdkHome = Split-Path -Parent (Split-Path -Parent $javaExe.FullName)

    if (Test-Path $jdkHome) {
        Remove-Item -Recurse -Force $jdkHome
    }

    Move-Item -Path $realJdkHome -Destination $jdkHome
}

Write-Host "正在配置用户环境变量 JAVA_HOME..." -ForegroundColor Cyan
[Environment]::SetEnvironmentVariable("JAVA_HOME", $jdkHome, "User")

$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
$javaBin = "%JAVA_HOME%\bin"

if ([string]::IsNullOrWhiteSpace($userPath)) {
    [Environment]::SetEnvironmentVariable("Path", $javaBin, "User")
} elseif ($userPath -notlike "*%JAVA_HOME%\bin*" -and $userPath -notlike "*$jdkHome\bin*") {
    [Environment]::SetEnvironmentVariable("Path", "$javaBin;$userPath", "User")
}

$env:JAVA_HOME = $jdkHome
$env:Path = "$jdkHome\bin;$env:Path"

Write-Host ""
Write-Host "Java 25 安装并配置完成。" -ForegroundColor Green
Write-Host "安装位置：$jdkHome"
Write-Host ""
Write-Host "当前窗口验证结果：" -ForegroundColor Cyan
java -version
javac -version
Write-Host ""
Write-Host "请关闭并重新打开 PowerShell 或 CMD，然后进入 Mod 项目目录运行：" -ForegroundColor Yellow
Write-Host "  .\gradlew.bat build"
