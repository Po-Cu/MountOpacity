package com.trae.mountopacity.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.trae.mountopacity.access.MountOpacityRenderContext;
import com.trae.mountopacity.access.MountOpacityRenderState;
import com.trae.mountopacity.config.MountOpacityConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.AbstractMinecartRenderer;
import net.minecraft.client.renderer.entity.state.MinecartRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.world.entity.vehicle.minecart.AbstractMinecart;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractMinecartRenderer.class)
public class AbstractMinecartRendererMixin {
    @Inject(
            method = "extractRenderState(Lnet/minecraft/world/entity/vehicle/minecart/AbstractMinecart;Lnet/minecraft/client/renderer/entity/state/MinecartRenderState;F)V",
            at = @At("RETURN")
    )
    private void mountOpacity$markMinecartState(AbstractMinecart minecart, MinecartRenderState state, float tickDelta, CallbackInfo ci) {
        ((MountOpacityRenderState) state).mountOpacity$setCurrentPlayerMount(mountOpacity$isCurrentPlayerVehicle(minecart));
    }

    @Inject(
            method = "submit(Lnet/minecraft/client/renderer/entity/state/MinecartRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V",
            at = @At("HEAD")
    )
    private void mountOpacity$beforeMinecartSubmit(
            MinecartRenderState state,
            PoseStack matrices,
            SubmitNodeCollector submitNodeCollector,
            CameraRenderState cameraRenderState,
            CallbackInfo ci
    ) {
        boolean currentPlayerVehicle = ((MountOpacityRenderState) state).mountOpacity$isCurrentPlayerMount();
        MountOpacityRenderContext.setOpacity(currentPlayerVehicle && MountOpacityConfig.shouldRenderVehicleTransparent()
                ? MountOpacityConfig.vehicleOpacityAsFloat()
                : 1.0F);
    }

    @Inject(
            method = "submit(Lnet/minecraft/client/renderer/entity/state/MinecartRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V",
            at = @At("RETURN")
    )
    private void mountOpacity$afterMinecartSubmit(
            MinecartRenderState state,
            PoseStack matrices,
            SubmitNodeCollector submitNodeCollector,
            CameraRenderState cameraRenderState,
            CallbackInfo ci
    ) {
        MountOpacityRenderContext.clear();
    }

    @Unique
    private boolean mountOpacity$isCurrentPlayerVehicle(AbstractMinecart minecart) {
        Minecraft client = Minecraft.getInstance();

        return client.player != null
                && client.player.isPassenger()
                && client.player.getVehicle() == minecart;
    }
}
