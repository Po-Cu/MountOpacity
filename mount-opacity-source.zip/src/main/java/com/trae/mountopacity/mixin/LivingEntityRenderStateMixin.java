package com.trae.mountopacity.mixin;

import com.trae.mountopacity.access.MountOpacityRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(LivingEntityRenderState.class)
public class LivingEntityRenderStateMixin implements MountOpacityRenderState {
    @Unique
    private boolean mountOpacity$currentPlayerMount;

    @Override
    public boolean mountOpacity$isCurrentPlayerMount() {
        return mountOpacity$currentPlayerMount;
    }

    @Override
    public void mountOpacity$setCurrentPlayerMount(boolean currentPlayerMount) {
        mountOpacity$currentPlayerMount = currentPlayerMount;
    }
}
