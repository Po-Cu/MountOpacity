package com.trae.mountopacity.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.trae.mountopacity.access.MountOpacityRenderContext;
import com.trae.mountopacity.access.MountOpacityRenderState;
import com.trae.mountopacity.config.MountOpacityConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin<T extends LivingEntity, S extends LivingEntityRenderState, M extends EntityModel<? super S>> {
    @Unique
    private boolean mountOpacity$renderingPlayerMount;

    @Inject(
            method = "extractRenderState(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;F)V",
            at = @At("RETURN")
    )
    private void mountOpacity$markRenderState(
            T entity,
            S state,
            float tickDelta,
            CallbackInfo ci
    ) {
        ((MountOpacityRenderState) state).mountOpacity$setCurrentPlayerMount(mountOpacity$isCurrentPlayerMount(entity));
    }

    @Inject(
            method = "submit(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V",
            at = @At("HEAD")
    )
    private void mountOpacity$beforeSubmit(
            S state,
            PoseStack matrices,
            SubmitNodeCollector submitNodeCollector,
            CameraRenderState cameraRenderState,
            CallbackInfo ci
    ) {
        mountOpacity$renderingPlayerMount = ((MountOpacityRenderState) state).mountOpacity$isCurrentPlayerMount();
        MountOpacityRenderContext.setRenderingPlayerMount(mountOpacity$renderingPlayerMount);
    }

    @Inject(
            method = "submit(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V",
            at = @At("RETURN")
    )
    private void mountOpacity$afterSubmit(
            S state,
            PoseStack matrices,
            SubmitNodeCollector submitNodeCollector,
            CameraRenderState cameraRenderState,
            CallbackInfo ci
    ) {
        mountOpacity$renderingPlayerMount = false;
        MountOpacityRenderContext.clear();
    }

    @ModifyArgs(
            method = "submit(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;getRenderType(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;ZZZ)Lnet/minecraft/client/renderer/rendertype/RenderType;"
            )
    )
    private void mountOpacity$useTranslucentLayer(Args args) {
        if (!mountOpacity$renderingPlayerMount || !MountOpacityConfig.shouldRenderTransparent()) {
            return;
        }

        args.set(1, false);
        args.set(2, true);
    }

    @ModifyArgs(
            method = "submit(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/SubmitNodeCollector;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/rendertype/RenderType;IIILnet/minecraft/client/renderer/texture/TextureAtlasSprite;ILnet/minecraft/client/renderer/feature/ModelFeatureRenderer$CrumblingOverlay;)V"
            )
    )
    private void mountOpacity$changeModelAlpha(Args args) {
        if (!mountOpacity$renderingPlayerMount || !MountOpacityConfig.shouldRenderTransparent()) {
            return;
        }

        int originalColor = args.get(6);

        args.set(6, MountOpacityRenderContext.applyOpacityToColor(originalColor));
    }

    @Unique
    private boolean mountOpacity$isCurrentPlayerMount(T entity) {
        Minecraft client = Minecraft.getInstance();

        return client.player != null
                && client.player.isPassenger()
                && client.player.getVehicle() == entity;
    }
}
