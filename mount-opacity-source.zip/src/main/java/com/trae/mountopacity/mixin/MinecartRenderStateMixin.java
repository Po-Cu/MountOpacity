package com.trae.mountopacity.mixin;

import com.trae.mountopacity.access.MountOpacityRenderState;
import net.minecraft.client.renderer.entity.state.MinecartRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(MinecartRenderState.class)
public class MinecartRenderStateMixin implements MountOpacityRenderState {
    @Unique
    private boolean mountOpacity$currentPlayerMount;

    @Override
    public boolean mountOpacity$isCurrentPlayerMount() {
        return mountOpacity$currentPlayerMount;
    }

    @Override
    public void mountOpacity$setCurrentPlayerMount(boolean currentPlayerMount) {
        mountOpacity$currentPlayerMount = currentPlayerMount;
    }
}
