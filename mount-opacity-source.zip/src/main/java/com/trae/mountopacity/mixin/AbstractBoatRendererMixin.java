package com.trae.mountopacity.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.trae.mountopacity.access.MountOpacityRenderContext;
import com.trae.mountopacity.access.MountOpacityRenderState;
import com.trae.mountopacity.config.MountOpacityConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.AbstractBoatRenderer;
import net.minecraft.client.renderer.entity.state.BoatRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.world.entity.vehicle.boat.AbstractBoat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractBoatRenderer.class)
public class AbstractBoatRendererMixin {
    @Inject(
            method = "extractRenderState(Lnet/minecraft/world/entity/vehicle/boat/AbstractBoat;Lnet/minecraft/client/renderer/entity/state/BoatRenderState;F)V",
            at = @At("RETURN")
    )
    private void mountOpacity$markBoatState(AbstractBoat boat, BoatRenderState state, float tickDelta, CallbackInfo ci) {
        ((MountOpacityRenderState) state).mountOpacity$setCurrentPlayerMount(mountOpacity$isCurrentPlayerVehicle(boat));
    }

    @Inject(
            method = "submit(Lnet/minecraft/client/renderer/entity/state/BoatRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V",
            at = @At("HEAD")
    )
    private void mountOpacity$beforeBoatSubmit(
            BoatRenderState state,
            PoseStack matrices,
            SubmitNodeCollector submitNodeCollector,
            CameraRenderState cameraRenderState,
            CallbackInfo ci
    ) {
        boolean currentPlayerVehicle = ((MountOpacityRenderState) state).mountOpacity$isCurrentPlayerMount();
        MountOpacityRenderContext.setOpacity(currentPlayerVehicle && MountOpacityConfig.shouldRenderVehicleTransparent()
                ? MountOpacityConfig.vehicleOpacityAsFloat()
                : 1.0F);
    }

    @Inject(
            method = "submit(Lnet/minecraft/client/renderer/entity/state/BoatRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V",
            at = @At("RETURN")
    )
    private void mountOpacity$afterBoatSubmit(
            BoatRenderState state,
            PoseStack matrices,
            SubmitNodeCollector submitNodeCollector,
            CameraRenderState cameraRenderState,
            CallbackInfo ci
    ) {
        MountOpacityRenderContext.clear();
    }

    @Unique
    private boolean mountOpacity$isCurrentPlayerVehicle(AbstractBoat boat) {
        Minecraft client = Minecraft.getInstance();

        return client.player != null
                && client.player.isPassenger()
                && client.player.getVehicle() == boat;
    }
}
