package com.trae.mountopacity.mixin;

public interface MountOpacityRenderState {
    boolean mountOpacity$isCurrentPlayerMount();

    void mountOpacity$setCurrentPlayerMount(boolean currentPlayerMount);
}
