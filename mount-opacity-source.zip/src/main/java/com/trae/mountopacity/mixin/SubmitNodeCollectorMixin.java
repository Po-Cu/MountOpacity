package com.trae.mountopacity.mixin;

import com.trae.mountopacity.access.MountOpacityRenderContext;
import net.minecraft.client.renderer.SubmitNodeCollection;
import net.minecraft.client.renderer.SubmitNodeStorage;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin({SubmitNodeCollection.class, SubmitNodeStorage.class})
public class SubmitNodeCollectorMixin {
    @ModifyVariable(
            method = "submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/rendertype/RenderType;IIILnet/minecraft/client/renderer/texture/TextureAtlasSprite;ILnet/minecraft/client/renderer/feature/ModelFeatureRenderer$CrumblingOverlay;)V",
            at = @At("HEAD"),
            argsOnly = true,
            ordinal = 2
    )
    private int mountOpacity$applyOpacityToSubmittedModel(int color) {
        return MountOpacityRenderContext.applyOpacityToColor(color);
    }
}
