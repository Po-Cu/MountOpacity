package com.trae.mountopacity.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.trae.mountopacity.MountOpacityClient;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public class MountOpacityConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir()
            .resolve(MountOpacityClient.MOD_ID + ".json");

    public static MountOpacityConfig INSTANCE = new MountOpacityConfig();

    public double opacity = 0.5D;
    public double vehicleOpacity = 0.5D;

    public static void load() {
        if (Files.exists(CONFIG_PATH)) {
            try (Reader reader = Files.newBufferedReader(CONFIG_PATH)) {
                JsonObject json = GSON.fromJson(reader, JsonObject.class);
                MountOpacityConfig loaded = new MountOpacityConfig();

                if (json != null) {
                    if (json.has("opacity")) {
                        loaded.opacity = json.get("opacity").getAsDouble();
                    }

                    if (json.has("vehicleOpacity")) {
                        loaded.vehicleOpacity = json.get("vehicleOpacity").getAsDouble();
                    }
                }

                INSTANCE = loaded;
            } catch (IOException ignored) {
                INSTANCE = new MountOpacityConfig();
            }
        }

        INSTANCE.normalize();
        save();
    }

    public static void save() {
        INSTANCE.normalize();

        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(CONFIG_PATH)) {
                GSON.toJson(INSTANCE, writer);
            }
        } catch (IOException ignored) {
        }
    }

    public static float opacityAsFloat() {
        return (float) INSTANCE.opacity;
    }

    public static float vehicleOpacityAsFloat() {
        return (float) INSTANCE.vehicleOpacity;
    }

    public static boolean shouldRenderTransparent() {
        return INSTANCE.opacity < 1.0D;
    }

    public static boolean shouldRenderVehicleTransparent() {
        return INSTANCE.vehicleOpacity < 1.0D;
    }

    public void normalize() {
        opacity = clamp(opacity);
        vehicleOpacity = clamp(vehicleOpacity);
    }

    public static double clamp(double value) {
        if (Double.isNaN(value)) {
            return 1.0D;
        }

        return Math.max(0.0D, Math.min(1.0D, value));
    }
}
