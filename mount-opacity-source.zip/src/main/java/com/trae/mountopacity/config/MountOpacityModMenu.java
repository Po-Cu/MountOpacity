package com.trae.mountopacity.config;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class MountOpacityModMenu implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return MountOpacityModMenu::createConfigScreen;
    }

    private static Screen createConfigScreen(Screen parent) {
        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(Component.translatable("text.autoconfig.mount-opacity.title"));

        ConfigEntryBuilder entryBuilder = builder.entryBuilder();
        ConfigCategory general = builder.getOrCreateCategory(Component.translatable("mount-opacity.config.category.general"));

        general.addEntry(entryBuilder
                .startDoubleField(
                        Component.translatable("mount-opacity.config.option.opacity"),
                        MountOpacityConfig.INSTANCE.opacity
                )
                .setDefaultValue(0.5D)
                .setMin(0.0D)
                .setMax(1.0D)
                .setTooltip(Component.translatable("mount-opacity.config.option.opacity.tooltip"))
                .setSaveConsumer(value -> MountOpacityConfig.INSTANCE.opacity = MountOpacityConfig.clamp(value))
                .build());

        general.addEntry(entryBuilder
                .startDoubleField(
                        Component.translatable("mount-opacity.config.option.vehicle_opacity"),
                        MountOpacityConfig.INSTANCE.vehicleOpacity
                )
                .setDefaultValue(0.5D)
                .setMin(0.0D)
                .setMax(1.0D)
                .setTooltip(Component.translatable("mount-opacity.config.option.vehicle_opacity.tooltip"))
                .setSaveConsumer(value -> MountOpacityConfig.INSTANCE.vehicleOpacity = MountOpacityConfig.clamp(value))
                .build());

        builder.setSavingRunnable(MountOpacityConfig::save);
        return builder.build();
    }
}
