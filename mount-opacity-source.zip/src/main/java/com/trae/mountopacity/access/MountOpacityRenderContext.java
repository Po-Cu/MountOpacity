package com.trae.mountopacity.access;

import com.trae.mountopacity.config.MountOpacityConfig;

public final class MountOpacityRenderContext {
    private static final ThreadLocal<Float> ACTIVE_OPACITY = ThreadLocal.withInitial(() -> 1.0F);

    private MountOpacityRenderContext() {
    }

    public static void setRenderingPlayerMount(boolean renderingPlayerMount) {
        setOpacity(renderingPlayerMount && MountOpacityConfig.shouldRenderTransparent()
                ? MountOpacityConfig.opacityAsFloat()
                : 1.0F);
    }

    public static void setOpacity(float opacity) {
        ACTIVE_OPACITY.set(Math.max(0.0F, Math.min(1.0F, opacity)));
    }

    public static void clear() {
        ACTIVE_OPACITY.remove();
    }

    public static boolean shouldApplyOpacity() {
        return ACTIVE_OPACITY.get() < 1.0F;
    }

    public static int applyOpacityToColor(int color) {
        if (!shouldApplyOpacity()) {
            return color;
        }

        int alpha = Math.round(ACTIVE_OPACITY.get() * 255.0F);
        return (alpha << 24) | (color & 0x00FFFFFF);
    }
}
