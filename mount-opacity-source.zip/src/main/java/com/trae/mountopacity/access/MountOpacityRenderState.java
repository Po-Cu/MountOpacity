package com.trae.mountopacity.access;

public interface MountOpacityRenderState {
    boolean mountOpacity$isCurrentPlayerMount();

    void mountOpacity$setCurrentPlayerMount(boolean currentPlayerMount);
}
