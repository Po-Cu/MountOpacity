package com.trae.mountopacity;

import com.trae.mountopacity.config.MountOpacityConfig;
import net.fabricmc.api.ClientModInitializer;

public class MountOpacityClient implements ClientModInitializer {
    public static final String MOD_ID = "mount-opacity";

    @Override
    public void onInitializeClient() {
        MountOpacityConfig.load();
    }
}
